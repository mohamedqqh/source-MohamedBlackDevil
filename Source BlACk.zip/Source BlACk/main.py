cat > main.py << 'EOF'
#!/usr/bin/env python3
from telethon import TelegramClient, events, Button
import asyncio
import sqlite3
import os
import random
from datetime import datetime

# استيراد كل الإعدادات من config
from config import * 

print("✦ 𝐒𝐎𝐔𝐑𝐂𝐄 𝐁𝐋𝐀𝐂𝐊 𝐃𝐄𝐕𝐈𝐋 ✦")
print("🚀 جاري التشغيل...")

async def main():
    client = TelegramClient("sessions/black_devil", API_ID, API_HASH)
    
    await client.start()
    me = await client.get_me()
    
    print(f"✅ تم التسجيل كـ: {me.first_name}")
    
    @client.on(events.NewMessage(pattern='.معلومات'))
    async def info_handler(event):
        user = await event.get_sender()
        await event.reply(f"""
✦ معلومات الحساب ✦

👤 الاسم: {user.first_name}
🆔 ايدي: `{user.id}`
📞 اليوزر: @{user.username or "لا يوجد"}

✦ المطور: {DEV_USERNAME}
✦ القناة: {CHANNEL_USERNAME}
        """)
    
    @client.on(events.NewMessage(pattern='.بداية'))
    async def start_handler(event):
        await event.reply(f"""
✦ مرحبا بك في {SOURCE_NAME} ✦

🎯 الأوامر المتاحة:
• `.معلومات` - معلومات الحساب
• `.سرقه` - سرقة اسم (بالرد)
• `.حب` - إرسال قلب ناري

👑 المطور: {DEV_USERNAME}
📢 القناة: {CHANNEL_USERNAME}
        """)
    
    print("✨ السورس شغال الآن! اكتب .بداية في أي دردشة")
    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
EOF