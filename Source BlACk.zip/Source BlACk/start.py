#!/usr/bin/env python3
import os
import sys
import subprocess

def check_requirements():
    print("✦ جاري التحقق من المتطلبات...")
    try:
        import telethon
        import pyrogram
        import aiohttp
        print("✅ جميع المتطلبات مثبتة")
    except ImportError:
        print("📦 جاري تثبيت المتطلبات...")
        os.system("pip install -r requirements.txt")

def create_folders():
    folders = [
        "sessions",
        "downloads", 
        "downloads/photos",
        "downloads/voices",
        "downloads/stories",
        "database",
        "modules"
    ]
    
    for folder in folders:
        os.makedirs(folder, exist_ok=True)
        print(f"✅ تم إنشاء مجلد: {folder}")

def main():
    print("""
✦ ━━━━━━━━━━━━━━━━━━━━━━━ ✦
      𝐒𝐎𝐔𝐑𝐂𝐄 𝐁𝐋𝐀𝐂𝐊 𝐃𝐄𝐕𝐈𝐋
✦ ━━━━━━━━━━━━━━━━━━━━━━━ ✦
    """)
    
    check_requirements()
    create_folders()
    
    print("🚀 جاري تشغيل السورس...")
    os.system("python3 main.py")

if __name__ == "__main__":
    main()