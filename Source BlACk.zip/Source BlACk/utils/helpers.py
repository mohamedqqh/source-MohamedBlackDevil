import sqlite3
import os
from datetime import datetime

def get_user_from_event(event):
    """الحصول على المستخدم من الرسالة"""
    try:
        if event.reply_to_msg_id:
            replied = await event.get_reply_message()
            return replied.sender
        else:
            return event.sender
    except:
        return None

def is_user_admin(user_id):
    """التحقق إذا كان المستخدم أدمن"""
    conn = sqlite3.connect('database/users.db')
    cursor = conn.cursor()
    cursor.execute('SELECT is_admin FROM users WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()
    conn.close()
    return result and result[0] == 1

def save_user_photo(user_id, file_path):
    """حفظ صورة المستخدم في قاعدة البيانات"""
    conn = sqlite3.connect('database/users.db')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO saved_photos (user_id, file_path, save_date) VALUES (?, ?, ?)',
                   (user_id, file_path, datetime.now().isoformat()))
    conn.commit()
    conn.close()

def get_user_photos_count(user_id):
    """عدد صور المستخدم المحفوظة"""
    conn = sqlite3.connect('database/users.db')
    cursor = conn.cursor()
    cursor.execute('SELECT COUNT(*) FROM saved_photos WHERE user_id = ?', (user_id,))
    result = cursor.fetchone()[0]
    conn.close()
    return result