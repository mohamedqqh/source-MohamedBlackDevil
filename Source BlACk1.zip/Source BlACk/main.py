cat > main.py << 'EOF'
#!/usr/bin/env python3
from telethon import TelegramClient, events
import asyncio
import random

# البيانات الأساسية
API_ID = 12548557
API_HASH = "b4ddb955fd4c18d7f38d0dd784e2c760"
SOURCE_NAME = "✦ 𝐒𝐎𝐔𝐑𝐂𝐄 𝐁𝐋𝐀𝐂𝐊 𝐃𝐄𝐕𝐈𝐋 ✦"
DEV_USERNAME = "@BL_TH"
CHANNEL_USERNAME = "@S_S_H_44"

print(f"🚀 {SOURCE_NAME} - جاري التشغيل...")

async def main():
    client = TelegramClient("sessions/black_devil", API_ID, API_HASH)
    
    await client.start()
    me = await client.get_me()
    
    print(f"✅ تم التسجيل كـ: {me.first_name}")
    
    @client.on(events.NewMessage(pattern='.معلومات'))
    async def info_handler(event):
        user = await event.get_sender()
        await event.reply(f"""
✦ **معلومات الحساب** ✦

👤 **الاسم:** {user.first_name}
🆔 **ايدي:** `{user.id}`
📞 **اليوزر:** @{user.username or "لا يوجد"}

✦ **المطور:** {DEV_USERNAME}
✦ **القناة:** {CHANNEL_USERNAME}
        """)
    
    @client.on(events.NewMessage(pattern='.بداية'))
    async def start_handler(event):
        await event.reply(f"""
✦ **مرحبا بك في {SOURCE_NAME}** ✦

🎯 **الأوامر المتاحة:**
• `.معلومات` - معلومات الحساب
• `.سرقه` - سرقة اسم (بالرد)
• `.حب` - إرسال قلب ناري

👑 **المطور:** {DEV_USERNAME}
📢 **القناة:** {CHANNEL_USERNAME}
        """)
    
    @client.on(events.NewMessage(pattern='.سرقه'))
    async def steal_name(event):
        if event.reply_to_msg_id:
            await event.reply("😂 ✦ تم سرقة الاسم بنجاح!")
        else:
            await event.reply("⚠️ ✦ يرجى الرد على الشخص")
    
    @client.on(events.NewMessage(pattern='.حب'))
    async def send_love(event):
        hearts = ["❤️", "🧡", "💛", "💚", "💙", "💜"]
        fire_heart = "".join(random.choices(hearts, k=8))
        await event.reply(f"🔥 ✦ {fire_heart}")
    
    print("✨ السورس شغال! اكتب .بداية في أي دردشة")
    await client.run_until_disconnected()

if __name__ == "__main__":
    asyncio.run(main())
EOF