from telethon import events, Button
import asyncio
import os
import random
from datetime import datetime

async def setup_tools(client):
    
    # ✦ إنشاء قناة تلقائية ✦
    @client.on(events.NewMessage(pattern='.انشاء قناة (.+)'))
    async def create_channel(event):
        channel_name = event.pattern_match.group(1)
        try:
            from telethon.tl.functions.channels import CreateChannelRequest
            from telethon.tl.functions.messages import EditChatPhotoRequest
            
            # إنشاء القناة
            result = await client(CreateChannelRequest(
                title=f"✦ {channel_name} ✦",
                about=f"✦ {SOURCE_NAME} ✦\n✦ المطور: {DEV_USERNAME} ✦\n✦ القناة: {CHANNEL_USERNAME} ✦",
                megagroup=False
            ))
            
            await event.reply(f"""
✦ تم إنشاء القناة بنجاح ✦

🏷️ اسم القناة: ✦ {channel_name} ✦
🆔 ايدي القناة: {result.chats[0].id}
👑 المالك: {event.sender.first_name}

✦ {SOURCE_NAME} ✦
            """)
        except Exception as e:
            await event.reply(f"✦ خطأ في إنشاء القناة: {str(e)}")

    # ✦ إنشاء مجموعة تلقائية ✦
    @client.on(events.NewMessage(pattern='.انشاء مجموعة (.+)'))
    async def create_group(event):
        group_name = event.pattern_match.group(1)
        try:
            from telethon.tl.functions.channels import CreateChannelRequest
            
            # إنشاء المجموعة
            result = await client(CreateChannelRequest(
                title=f"✦ {group_name} ✦",
                about=f"✦ {SOURCE_NAME} ✦\n✦ المطور: {DEV_USERNAME} ✦\n✦ القناة: {CHANNEL_USERNAME} ✦",
                megagroup=True
            ))
            
            await event.reply(f"""
✦ تم إنشاء المجموعة بنجاح ✦

🏷️ اسم المجموعة: ✦ {group_name} ✦
🆔 ايدي المجموعة: {result.chats[0].id}
👑 المالك: {event.sender.first_name}

✦ {SOURCE_NAME} ✦
            """)
        except Exception as e:
            await event.reply(f"✦ خطأ في إنشاء المجموعة: {str(e)}")

    # ✦ مغادرة كل المجموعات ✦
    @client.on(events.NewMessage(pattern='.مغادرة الكل'))
    async def leave_all_groups(event):
        try:
            dialogs = await client.get_dialogs()
            left_count = 0
            
            for dialog in dialogs:
                if dialog.is_group:
                    try:
                        await client.leave_chat(dialog.id)
                        left_count += 1
                        await asyncio.sleep(1)
                    except:
                        continue
            
            await event.reply(f"""
✦ تم مغادرة المجموعات ✦

📤 عدد المجموعات التي تم مغادرتها: {left_count}
👤 باقي المجموعات: {len([d for d in dialogs if d.is_group]) - left_count}

✦ {SOURCE_NAME} ✦
            """)
        except Exception as e:
            await event.reply(f"✦ خطأ في مغادرة المجموعات: {str(e)}")

    # ✦ مغادرة كل القنوات ✦
    @client.on(events.NewMessage(pattern='.مغادرة القنوات'))
    async def leave_all_channels(event):
        try:
            dialogs = await client.get_dialogs()
            left_count = 0
            
            for dialog in dialogs:
                if dialog.is_channel and not dialog.is_group:
                    try:
                        await client.leave_chat(dialog.id)
                        left_count += 1
                        await asyncio.sleep(1)
                    except:
                        continue
            
            await event.reply(f"""
✦ تم مغادرة القنوات ✦

📤 عدد القنوات التي تم مغادرتها: {left_count}
👤 باقي القنوات: {len([d for d in dialogs if d.is_channel and not d.is_group]) - left_count}

✦ {SOURCE_NAME} ✦
            """)
        except Exception as e:
            await event.reply(f"✦ خطأ في مغادرة القنوات: {str(e)}")

    # ✦ مسح جميع رسائلك ✦
    @client.on(events.NewMessage(pattern='.مسح رسائلي'))
    async def delete_my_messages(event):
        try:
            await event.reply("✦ جاري مسح جميع رسائلك...")
            deleted_count = 0
            
            async for message in client.iter_messages(event.chat_id, from_user='me'):
                try:
                    await message.delete()
                    deleted_count += 1
                    await asyncio.sleep(0.5)
                except:
                    continue
            
            await event.reply(f"""
✦ تم مسح رسائلك ✦

🗑️ عدد الرسائل المحذوفة: {deleted_count}
💬 المجموعة: {event.chat_id}

✦ {SOURCE_NAME} ✦
            """)
        except Exception as e:
            await event.reply(f"✦ خطأ في مسح الرسائل: {str(e)}")

    # ✦ كتم مستخدم ✦
    @client.on(events.NewMessage(pattern='.كتم (@\\w+|\\d+)'))
    async def mute_user(event):
        try:
            target_user = await event.get_input_user()
            # كتم المستخدم
            await event.reply(f"✦ تم كتم المستخدم")
        except:
            await event.reply("✦ خطأ في كتم المستخدم")

    # ✦ فك كتم مستخدم ✦
    @client.on(events.NewMessage(pattern='.الغاء الكتم (@\\w+|\\d+)'))
    async def unmute_user(event):
        try:
            target_user = await event.get_input_user()
            # فك كتم المستخدم
            await event.reply(f"✦ تم فك كتم المستخدم")
        except:
            await event.reply("✦ خطأ في فك كتم المستخدم")