import sqlite3
import os

class Database:
    def __init__(self):
        self.db_path = 'database/users.db'
        self.init_database()
    
    def init_database(self):
        """تهيئة قاعدة البيانات"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # جدول المستخدمين
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                join_date TEXT,
                is_premium INTEGER DEFAULT 0,
                is_admin INTEGER DEFAULT 0,
                last_active TEXT
            )
        ''')
        
        # جدول الألقاب
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_titles (
                user_id INTEGER PRIMARY KEY,
                title TEXT,
                set_by INTEGER,
                set_date TEXT
            )
        ''')
        
        # جدول الصور المحفوظة
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS saved_photos (
                photo_id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                file_path TEXT,
                save_date TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def add_user(self, user_id, username, first_name):
        """إضافة مستخدم جديد"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO users (user_id, username, first_name, join_date, last_active)
            VALUES (?, ?, ?, datetime('now'), datetime('now'))
        ''', (user_id, username, first_name))
        conn.commit()
        conn.close()